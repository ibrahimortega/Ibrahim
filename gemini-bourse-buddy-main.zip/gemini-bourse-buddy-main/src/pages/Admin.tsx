import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useUserRole, AppRole } from "@/hooks/useUserRole";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import { Shield, Trash2, UserPlus, Users, BookOpen, Bell, Eye } from "lucide-react";

interface ProfileRow {
  user_id: string;
  full_name: string | null;
  level: string | null;
  created_at: string;
  roles: AppRole[];
}

const Admin = () => {
  const navigate = useNavigate();
  const { isAdmin, loading: roleLoading } = useUserRole();
  const [profiles, setProfiles] = useState<ProfileRow[]>([]);
  const [stats, setStats] = useState({ users: 0, courses: 0, alerts: 0, watchlist: 0 });
  const [loading, setLoading] = useState(true);
  const [newAdminId, setNewAdminId] = useState("");

  useEffect(() => {
    if (roleLoading) return;
    if (!isAdmin) {
      toast.error("هذه الصفحة للمشرفين فقط");
      navigate("/");
      return;
    }
    void loadData();
  }, [isAdmin, roleLoading, navigate]);

  const loadData = async () => {
    setLoading(true);
    const [profRes, rolesRes, coursesRes, alertsRes, watchRes] = await Promise.all([
      supabase.from("profiles").select("user_id, full_name, level, created_at").order("created_at", { ascending: false }),
      supabase.from("user_roles").select("user_id, role"),
      supabase.from("courses").select("id", { count: "exact", head: true }),
      supabase.from("price_alerts").select("id", { count: "exact", head: true }),
      supabase.from("watchlist").select("id", { count: "exact", head: true }),
    ]);

    const rolesMap = new Map<string, AppRole[]>();
    (rolesRes.data ?? []).forEach((r: any) => {
      const arr = rolesMap.get(r.user_id) ?? [];
      arr.push(r.role);
      rolesMap.set(r.user_id, arr);
    });

    const merged: ProfileRow[] = (profRes.data ?? []).map((p: any) => ({
      ...p,
      roles: rolesMap.get(p.user_id) ?? [],
    }));

    setProfiles(merged);
    setStats({
      users: merged.length,
      courses: coursesRes.count ?? 0,
      alerts: alertsRes.count ?? 0,
      watchlist: watchRes.count ?? 0,
    });
    setLoading(false);
  };

  const grantAdmin = async (userId: string) => {
    const { error } = await supabase.from("user_roles").insert({ user_id: userId, role: "admin" });
    if (error) return toast.error(error.message);
    toast.success("تم تعيين الأدمن");
    setNewAdminId("");
    void loadData();
  };

  const revokeRole = async (userId: string, role: AppRole) => {
    const { error } = await supabase.from("user_roles").delete().eq("user_id", userId).eq("role", role);
    if (error) return toast.error(error.message);
    toast.success("تم إزالة الصلاحية");
    void loadData();
  };

  if (roleLoading || loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <p className="text-muted-foreground">جاري التحميل...</p>
      </div>
    );
  }

  const cards = [
    { label: "المستخدمين", value: stats.users, icon: Users },
    { label: "الكورسات", value: stats.courses, icon: BookOpen },
    { label: "تنبيهات الأسعار", value: stats.alerts, icon: Bell },
    { label: "قوائم المراقبة", value: stats.watchlist, icon: Eye },
  ];

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <Header />
      <main className="flex-1 container py-8 space-y-8" dir="rtl">
        <div className="flex items-center gap-3">
          <Shield className="h-7 w-7 text-gold" />
          <h1 className="text-3xl font-bold">لوحة تحكم الأدمن</h1>
        </div>

        <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
          {cards.map((c) => (
            <Card key={c.label}>
              <CardContent className="flex items-center gap-3 p-5">
                <div className="rounded-lg bg-gold/10 p-3">
                  <c.icon className="h-5 w-5 text-gold" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">{c.label}</p>
                  <p className="text-2xl font-bold">{c.value}</p>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <UserPlus className="h-5 w-5 text-gold" /> تعيين أدمن جديد
            </CardTitle>
          </CardHeader>
          <CardContent className="flex flex-col gap-3 md:flex-row">
            <Input
              placeholder="User ID (UUID)"
              value={newAdminId}
              onChange={(e) => setNewAdminId(e.target.value)}
            />
            <Button onClick={() => grantAdmin(newAdminId)} disabled={!newAdminId}>
              تعيين كأدمن
            </Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>المستخدمين ({profiles.length})</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            {profiles.map((p) => (
              <div key={p.user_id} className="flex flex-col gap-2 rounded-lg border border-border p-3 md:flex-row md:items-center md:justify-between">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <p className="font-semibold">{p.full_name ?? "—"}</p>
                    {p.roles.map((r) => (
                      <Badge key={r} variant={r === "admin" ? "default" : "secondary"}>
                        {r}
                      </Badge>
                    ))}
                  </div>
                  <p className="text-xs text-muted-foreground font-mono">{p.user_id}</p>
                </div>
                <div className="flex gap-2">
                  {!p.roles.includes("admin") && (
                    <Button size="sm" variant="outline" onClick={() => grantAdmin(p.user_id)}>
                      ترقية لأدمن
                    </Button>
                  )}
                  {p.roles.includes("admin") && (
                    <Button size="sm" variant="destructive" onClick={() => revokeRole(p.user_id, "admin")}>
                      <Trash2 className="h-4 w-4 ml-1" /> إزالة الأدمن
                    </Button>
                  )}
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      </main>
      <Footer />
    </div>
  );
};

export default Admin;
